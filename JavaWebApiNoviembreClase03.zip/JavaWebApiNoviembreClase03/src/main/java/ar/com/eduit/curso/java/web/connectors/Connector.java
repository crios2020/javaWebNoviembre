package ar.com.eduit.curso.java.web.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connector {

    private String driver = "org.mariadb.jdbc.Driver";
    private String url = "jdbc:mariadb://localhost:3306/javaWebNoviembre";
    private String user = "root";
    private String pass = "";

    public Connector() {
    }

    public Connector(String driver, String url, String user, String pass) {
        this.driver = driver;
        this.url = url;
        this.user = user;
        this.pass = pass;
    }

    public Connection getConnection(){
        try {
            Class.forName(driver);      //registra el driver
            return DriverManager.getConnection(url, user, pass);
        } catch (Exception e) {
            return null;
        }
    }
    
}
