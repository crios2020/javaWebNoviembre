package ar.com.eduit.curso.java.web.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Calculadora")
public class Calculadora extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/plain;charset=UTF-8");
		try(PrintWriter out=response.getWriter()){
			try{
				int nro1=Integer.parseInt(request.getParameter("nro1"));
				int nro2=Integer.parseInt(request.getParameter("nro2"));
				int resultado=nro1+nro2;
				out.println(resultado);
			} catch (Exception e) {
				out.println("error");
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
