package ar.com.eduit.curso.java.web.test;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.list.ArticuloRepositoryFactory;

public class TestRepository {
    public static void main(String[] args) {
        I_ArticuloRepository ar=ArticuloRepositoryFactory.getArticuloRepository();
        ar.save(new Articulo("Carpa",35000,10));
        ar.save(new Articulo("Termo",2300,20));
        ar.save(new Articulo("Silla",5000,10));
        ar.save(new Articulo("Cocina",5000,30));
        
        ar.getAll().forEach(System.out::println);
    }
}
