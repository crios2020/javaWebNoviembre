package ar.com.eduit.curso.java.web.services.rest;

import ar.com.eduit.curso.java.web.connectors.Connector;
import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ArticuloRepository;
import com.google.gson.Gson;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/articulos/v1")
public class ArticuloService {
    
    private I_ArticuloRepository ar=new ArticuloRepository(new Connector().getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio articulos V1 activo!";
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("alta")
    public int alta(
            @QueryParam("descripcion") String descripcion, 
            @QueryParam("precio") double precio, 
            @QueryParam("stock") int stock
    ){
        Articulo articulo=new Articulo(descripcion, precio, stock);
        ar.save(articulo);
        return articulo.getId();
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("all")
    public String getAll(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("likeDescripcion")
    public String getLikeDescripcion(@QueryParam("descripcion") String descripcion){
        return new Gson().toJson(ar.getLikeDescripcion(descripcion));
    }
    
}
