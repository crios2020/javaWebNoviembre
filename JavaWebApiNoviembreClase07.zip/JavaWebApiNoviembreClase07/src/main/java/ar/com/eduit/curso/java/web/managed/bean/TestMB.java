package ar.com.eduit.curso.java.web.managed.bean;

import java.io.Serializable;
import javax.enterprise.context.SessionScoped;
import javax.inject.Named;

@Named()
@SessionScoped
public class TestMB implements Serializable{       //testMB
    private String nombre="Ingrese su nombre";
    private String apellido="Ingrese su apellido";

    public void cargar(){
        System.out.println("****************************************************");
        System.out.println(nombre+" "+apellido);
        System.out.println("****************************************************");
        nombre="";
        apellido="";
        
        /*
        for(int a=1;a<=20;a++){
            nombre+="X";
            apellido+="O";
            try{ Thread.sleep(1000); }catch(Exception e){}
        }
        */
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

}
