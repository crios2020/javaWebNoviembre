package ar.com.eduit.curso.java.web.utils;

public class ParamFormat {
    public static String getParamFormat(String param){
        String param2="";
        
        for(int a=0; a<param.length(); a++){
            char car=param.charAt(a);
            
            if(car=='{') car='(';
            if(car=='}') car=')';
            if(car=='"') car=39;
            param2+=(char)car;
        }
        
        return param2;
    }
    
    public static void main(String[] args) {
        String texto="{\"id\":0,\"nombre\":\"Karina\",\"apellido\":\"Rios\",\"edad\":35,\"idArticulo\":1}";
        System.out.println(texto);
        System.out.println(getParamFormat(texto));
    }
}
