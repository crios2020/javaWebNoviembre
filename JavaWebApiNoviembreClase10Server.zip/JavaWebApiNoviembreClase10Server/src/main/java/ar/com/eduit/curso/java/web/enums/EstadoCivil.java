package ar.com.eduit.curso.java.web.enums;

public enum EstadoCivil {
    SOLTERO,
    CASADO,
    VIUDO,
    DIVORCIADO
}
