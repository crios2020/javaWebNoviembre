package ar.com.eduit.curso.java.web.services.rest;

import ar.com.eduit.curso.java.web.connectors.Connector;
import ar.com.eduit.curso.java.web.entities.Cliente;
import ar.com.eduit.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.com.eduit.curso.java.web.repositories.jdbc.ClienteRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import java.lang.reflect.Type;
import java.util.List;

@Path("/clientes/v1")
public class ClienteService {
    private I_ClienteRepository cr=new ClienteRepository(new Connector().getConnection());
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio Clientes V1 activo!";
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("all")
    public String getAll(){
        return new Gson().toJson(cr.getAll());
    }
    
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/byId")
    public String getById(@QueryParam("id")int id){
        return new Gson().toJson(cr.getById(id));
    }
        
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    @Path("likeApellido")
    public String getLikeApellido(@QueryParam("apellido") String apellido){
        return new Gson().toJson(cr.getLikeApellido(apellido));
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @Path("alta")
    public int alta(
            @QueryParam("nombre") String nombre, 
            @QueryParam("apellido") String apellido, 
            @QueryParam("edad") int edad,
            @QueryParam("idArticulo") int idArticulo
    ){
        nombre=nombre.replaceAll("_", " ");
        apellido=apellido.replaceAll("_", " ");
        Cliente cliente=new Cliente(nombre, apellido, edad, idArticulo);
        cr.save(cliente);
        return cliente.getId();
    }
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    //@Consumes(MediaType.APPLICATION_JSON)
    @Path("alta2")
    public int alta2(@QueryParam("clienteJson") String clienteJson){
        //Type type=new TypeToken<Cliente>(){}.getType();
        //Cliente cliente=new Gson().fromJson(clienteJson, type);
        //cr.save(cliente);
        //return cliente.getId();
        System.out.println("***************************************************");
        System.out.println(clienteJson);
        System.out.println("***************************************************");
        return 888;
    }
    
}
