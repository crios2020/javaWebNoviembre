package ar.com.eduit.curso.java.web.servlets;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

//@WebServlet("/UserSession")
public class UserSession extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("No se pueden ingresar párametros por este medio!");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		try {
			session.setAttribute("login", false);
			session.setAttribute("name", "");
			String user=request.getParameter("user");
			String pass=request.getParameter("pass");
			if(user.equals("root") & pass.equals("123")) {
				session.setAttribute("login", true);
				session.setAttribute("name", "root");
				response.sendRedirect("Bienvenidos.jsp");
			}else {
				response.sendRedirect("errorLogin.html");
			}
			
		} catch (Exception e) {
			System.out.println(e);
			response.sendRedirect("errorLogin.html");
		}
	}

}
