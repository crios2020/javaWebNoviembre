package javawebapinoviembrecliente;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class JavaWebApiNoviembreCliente {

    public static void main(String[] args) throws Exception{
        //String url="https://servicios.usig.buenosaires.gob.ar/normalizar?direccion=lavalle%20648";
        //System.out.println(responseBody(url));
        
        String server="http://localhost:8082/Clase03";
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Cocina&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Termo&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Lampara&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/ArticuloAlta?descripcion=Carpa&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos All");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/ArticuloAll"));
        System.out.println();
            
        System.out.println("****************************************************");
        System.out.println("Articulos LikeDescripcion");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/ArticuloLikeDescripcion?descripcion=ca"));
        System.out.println();
        
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode()+"\033[0m");
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode()+"\033[0m");
        }
        //response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
