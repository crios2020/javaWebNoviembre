package javawebapinoviembrecliente;

import ar.com.eduit.curso.java.web.entities.Articulo;
import ar.com.eduit.curso.java.web.entities.Cliente;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.IOException;
import java.lang.reflect.Type;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;

public class JavaWebApiNoviembreCliente {

    public static void main(String[] args) throws Exception{
        //String url="https://servicios.usig.buenosaires.gob.ar/normalizar?direccion=lavalle%20648";
        //System.out.println(responseBody(url));
        
        String server="http://localhost:8082/ServerNoviembre/webresources";
        
        System.out.println("****************************************************");
        System.out.println("Server");
        System.out.println("****************************************************");
        System.out.println(responseBody(server));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Info");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Cocina&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Termo&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Lampara&precio=3400&stock=100"));
        System.out.println();
        
        System.out.println("****************************************************");
        System.out.println("Articulos Altas");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1/alta?descripcion=Carpa&precio=3400&stock=100"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Articulos All");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1/all"));
        System.out.println();
               
        
        System.out.println("****************************************************");
        System.out.println("Articulos LikeDescripcion");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/articulos/v1/likeDescripcion?descripcion=ca"));
        System.out.println();
                 
        
        System.out.println("****************************************************");
        System.out.println("Clientes Info");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Clientes Alta");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/alta?nombre=Miriam&apellido=salina&edad=47&idArticulo=1"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Clientes Alta");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/alta?nombre=Javier&apellido=Santos&edad=47&idArticulo=1"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Clientes Alta");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/alta?nombre=Cristian&apellido=Molina&edad=36&idArticulo=1"));
        System.out.println();
                        
        
        System.out.println("****************************************************");
        System.out.println("Clientes Alta");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/alta?nombre=Eva&apellido=Riera&edad=30&idArticulo=1"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Clientes All");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/all"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Clientes byId");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/byId?id=5"));
        System.out.println();
        
        
        System.out.println("****************************************************");
        System.out.println("Clientes LikeApellido");
        System.out.println("****************************************************");
        System.out.println(responseBody(server+"/clientes/v1/likeApellido?apellido=go"));
        System.out.println();
                
        System.out.println("*******************************************");
        System.out.println("DeSerializado de Clientes");
        System.out.println("*******************************************");
        Type listType=new TypeToken<List<Cliente>>(){}.getType();
        List<Cliente>list=new Gson().fromJson(responseBody(server+"/clientes/v1/all"), listType);
        list.forEach(System.out::println);
        
        
        System.out.println("*******************************************");
        System.out.println("DeSerializado de Articulos");
        System.out.println("*******************************************");
        listType=new TypeToken<List<Articulo>>(){}.getType();
        List<Articulo>listArticulo=new Gson().fromJson(responseBody(server+"/articulos/v1/all"), listType);
        listArticulo.forEach(System.out::println);

        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode()+"\033[0m");
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode()+"\033[0m");
        }
        //response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
