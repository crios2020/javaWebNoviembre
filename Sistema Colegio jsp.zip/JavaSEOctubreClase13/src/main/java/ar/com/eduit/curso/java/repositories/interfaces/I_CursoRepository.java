package ar.com.eduit.curso.java.repositories.interfaces;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import ar.com.eduit.curso.java.entities.Curso;

public interface I_CursoRepository {
	void save(Curso curso);
	void remove(Curso curso);
	void update(Curso curso);
	default Curso getById(int id) {
		return getAll()
				.stream()
				.filter(c->c.getId()==id)
				.findFirst()
				.orElse(new Curso());
	}
	List<Curso> getAll();
	default List<Curso> getLikeTitulo(String titulo){
		if(titulo==null) return new ArrayList();
		return getAll()
				.stream()
				.filter(c->c.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
				.collect(Collectors.toList());
	}
	
	default Set<Curso> getSetLikeTitulo(String titulo){
		if(titulo==null) return new LinkedHashSet();
		return getAll()
				.stream()
				.filter(c->c.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
				.collect(Collectors.toSet());
	}
	
}