package ar.com.eduit.curso.java.test;

import ar.com.eduit.curso.java.connectors.Connector;
import ar.com.eduit.curso.java.entities.Alumno;
import ar.com.eduit.curso.java.entities.Curso;
import ar.com.eduit.curso.java.enums.Dia;
import ar.com.eduit.curso.java.enums.Turno;
import ar.com.eduit.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.com.eduit.curso.java.repositories.interfaces.I_CursoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.AlumnoRepository;
import ar.com.eduit.curso.java.repositories.jdbc.CursoRepository;

public class TestRepository {
	public static void main(String[] args) {
		I_CursoRepository cr=new CursoRepository(Connector.getConnection());
		Curso curso=new Curso("Carpinteria","Vargas",Dia.MARTES,Turno.MAÑANA);
		cr.save(curso);
		System.out.println(curso);
		//System.out.println(cr.getById(2));
		cr.remove(cr.getById(7));
		
		curso=cr.getById(5);
		curso.setTitulo("HTML");
		curso.setProfesor("Mendoza");
		cr.update(curso);
		
		System.out.println("***********************************************");
		cr.getAll().forEach(System.out::println);
		System.out.println("***********************************************");
		cr.getLikeTitulo("ja").forEach(System.out::println);
		System.out.println("***********************************************");
		cr.getSetLikeTitulo("ja").forEach(System.out::println);
		
		System.out.println("***********************************************");
		I_AlumnoRepository ar=new AlumnoRepository(Connector.getConnection());
		Alumno alumno=new Alumno("Nicolas","Leon",38,1);
		ar.save(alumno);
		System.out.println(alumno);
		
		ar.remove(ar.getById(7));
		
		alumno=ar.getById(9);
		alumno.setNombre("Karina");
		alumno.setApellido("Herrera");
		ar.update(alumno);
		System.out.println("***********************************************");
		ar.getAll().forEach(System.out::println);
		System.out.println("***********************************************");
		ar.getLikeApellido("as").forEach(System.out::println);
		System.out.println("***********************************************");
		ar.getByCurso(cr.getById(1)).forEach(System.out::println);
		
	}
}
